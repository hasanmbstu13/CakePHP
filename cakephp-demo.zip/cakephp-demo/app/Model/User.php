<?php

class User extends AppModel {



}

